<?php

namespace App\Models;

use MongoDB\Laravel\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class TrangNong extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'name',
        'phone',
        'area',
        'laonong_id',
        'store_id',
        'status',
    ];

    protected $attributes = [
        'status' => 'active',
    ];

    // Relationship tới Lão nông giám sát
    public function laonong()
    {
        // nếu SeniorFarmer dùng Mongo thì key thường là _id
        return $this->belongsTo(SeniorFarmer::class, 'laonong_id', '_id');
        // nếu SeniorFarmer dùng SQL thì đổi ownerKey thành 'id'
    }

    // Relationship tới Cửa hàng VTNN
    public function store()
    {
        return $this->belongsTo(Supplier::class, 'store_id', '_id');
        // nếu Supplier dùng SQL thì đổi ownerKey thành 'id'
    }

    public static function nextCode()
    {
        // an toàn hơn cho Mongo: sort theo code
        $last = self::orderBy('code', 'desc')->first();

        if (!$last || !$last->code) return 'TN001';

        $number = (int) substr($last->code, 2);
        $next = str_pad($number + 1, 3, '0', STR_PAD_LEFT);

        return 'TN' . $next;
    }
}
