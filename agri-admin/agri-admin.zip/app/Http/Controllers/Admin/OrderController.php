<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    // Danh sách đơn
    public function index(Request $request)
    {
        $query = Order::query();

        // Tìm kiếm theo mã đơn (code = rút gọn _id) hoặc địa chỉ giao hàng
        if ($search = $request->input('q')) {
            $query->where(function ($q) use ($search) {
                $q->where('_id', 'like', '%' . $search . '%')
                  ->orWhere('shippingAddress.address', 'like', '%' . $search . '%');
            });
        }

        // Lọc theo trạng thái (awaiting_payment, processing, ...)
        if ($status = $request->input('status')) {
            $query->where('status', $status);
        }

        $orders = $query
            ->orderBy('createdAt', 'desc')
            ->paginate(15);

        $statusOptions = Order::getStatusOptions();

        return view('orders.index', compact('orders', 'statusOptions'));
    }

    // Chi tiết đơn + timeline
    public function show(string $id)
    {
        // laravel-mongodb tự convert string sang ObjectId khi findOrFail
        $order = Order::with('items')->findOrFail($id);

        $steps = Order::getTimelineSteps();

        return view('orders.show', compact('order', 'steps'));
    }

public function tracking(Request $request)
{
    $query = Order::query();

    // Lọc theo trạng thái nếu có
    if ($status = $request->input('status')) {
        $query->where('status', $status);
    } else {
        // Mặc định: lấy tất cả các đơn hàng có trạng thái hợp lệ
        $query->whereIn('status', array_keys(Order::STATUSES));
    }

    // Lấy tất cả các đơn hàng
    $orders = $query->orderBy('createdAt', 'desc')->get();
    
    // Lấy các trạng thái để dùng cho filter
    $statusOptions = Order::getStatusOptions();

    return view('orders.tracking', compact('orders', 'statusOptions'));
}

public function approveByAdmin(string $id)
{
    $order = Order::findOrFail($id);

    // Chuyển trạng thái từ "Chờ Admin duyệt" -> "Đã duyệt → Chờ VTNN chuẩn bị hàng"
    if ($order->status === 'pending_admin_approval') {
        $order->status = 'zapproved_by_admin'; 
        $order->save();
    }

    return back()->with('success', 'Đơn hàng đã được duyệt.');
}

public function moveToPreparing(string $id)
{
    $order = Order::findOrFail($id);

    // Chuyển trạng thái từ "Đã duyệt → Chờ VTNN chuẩn bị hàng" -> "VTNN đã soạn hàng xong → Chờ lấy hàng"
    if ($order->status === 'approved_by_admin') {
        $order->status = 'preparing';
        $order->save();
    }

    return back()->with('success', 'Đơn hàng đã được chuẩn bị xong, chờ lấy hàng.');
}

public function moveToReadyForPickup(string $id)
{
    $order = Order::findOrFail($id);

    // Chuyển trạng thái từ "VTNN đã soạn hàng xong → Chờ lấy hàng" -> "Đã lấy hàng → Chờ thanh toán"
    if ($order->status === 'preparing') {
        $order->status = 'ready_for_pickup';
        $order->save();
    }

    return back()->with('success', 'Đơn hàng đã được lấy, chờ thanh toán.');
}

public function moveToAwaitingPayment(string $id)
{
    $order = Order::findOrFail($id);

    // Chuyển trạng thái từ "Đã lấy hàng → Chờ thanh toán" -> "Đã thanh toán → Đi giao hàng"
    if ($order->status === 'ready_for_pickup') {
        $order->status = 'awaiting_payment';
        $order->save();
    }

    return back()->with('success', 'Đơn hàng đã được thanh toán, đang đi giao.');
}

public function moveToOutForDelivery(string $id)
{
    $order = Order::findOrFail($id);

    // Chuyển trạng thái từ "Đã thanh toán → Đi giao hàng" -> "Đã giao hàng → Chờ khách xác nhận"
    if ($order->status === 'awaiting_payment') {
        $order->status = 'out_for_delivery';
        $order->save();
    }

    return back()->with('success', 'Đơn hàng đã được giao, chờ khách xác nhận.');
}

public function moveToDelivered(string $id)
{
    $order = Order::findOrFail($id);

    // Chuyển trạng thái từ "Đã giao hàng → Chờ khách xác nhận" -> "Khách đã xác nhận → Hoàn thành"
    if ($order->status === 'out_for_delivery') {
        $order->status = 'delivered';
        $order->save();
    }

    return back()->with('success', 'Khách đã xác nhận, đơn hàng đã hoàn thành.');
}

public function completeOrder(string $id)
{
    $order = Order::findOrFail($id);

    // Chuyển trạng thái từ "Khách đã xác nhận → Hoàn thành" -> "Hoàn thành"
    if ($order->status === 'delivered') {
        $order->status = 'completed';
        $order->save();
    }

    return back()->with('success', 'Đơn hàng đã hoàn thành.');
}

public function cancelOrder(string $id)
{
    $order = Order::findOrFail($id);

    // Chuyển trạng thái thành "Đã hủy"
    if ($order->status !== 'cancelled') {
        $order->status = 'cancelled';
        $order->save();
    }

    return back()->with('success', 'Đơn hàng đã bị hủy.');
  }
}
