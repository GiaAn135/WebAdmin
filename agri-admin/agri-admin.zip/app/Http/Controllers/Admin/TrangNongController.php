<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TrangNong;
use App\Models\SeniorFarmer;  
use App\Http\Controllers\LaoNongController;
use App\Models\Supplier; // model Cửa hàng VTNN
use Illuminate\Http\Request;

class TrangNongController extends Controller
{
    public function index(Request $request)
{
    $q = TrangNong::query();

    if ($s = $request->q) {
        $q->where('name', 'like', "%$s%")
          ->orWhere('phone', 'like', "%$s%");
    }

    $items = $q->orderBy('code')->paginate(20);

    $storeIds = $items->pluck('store_id')->filter()->unique()->values();
    $laonongIds = $items->pluck('laonong_id')->filter()->unique()->values();

    // Nếu Supplier/SeniorFarmer là Mongo model
    $stores = Supplier::whereIn('_id', $storeIds)->get()->keyBy('_id');
    $laonongs = SeniorFarmer::whereIn('_id', $laonongIds)->get()->keyBy('_id');

    // Nếu 2 model này là SQL thì đổi _id -> id
    // $stores = Supplier::whereIn('id', $storeIds)->get()->keyBy('id');
    // $laonongs = SeniorFarmer::whereIn('id', $laonongIds)->get()->keyBy('id');

    return view('trangnong.index', compact('items', 'stores', 'laonongs'));
}


    public function create()
    {
        $item = new TrangNong();

        // lấy danh sách lão nông & cửa hàng VTNN
        $laonongs = SeniorFarmer::orderBy('name')->get();        // field name của Lão nông
        $stores   = Supplier::orderBy('name')->get();       // hoặc store_name, shop_name...

        return view('trangnong.form', compact('item', 'laonongs', 'stores'));
    }

    public function store(Request $r)
    {
        $data = $r->validate([
            'name'       => 'required|string',
            'phone'      => 'required|string',
            'area'       => 'required|string',
            'laonong_id' => 'required',   // chọn từ dropdown
            'store_id'   => 'required',   // chọn từ dropdown
            'status'     => 'required',
        ]);

        $data['code'] = TrangNong::nextCode(); // TN001...

        TrangNong::create($data);

        return redirect()->route('trangnong.index')
            ->with('success', 'Tạo tráng nông mới thành công !!');
    }

    public function edit($id)
    {
        $item = TrangNong::findOrFail($id);

        $laonongs = SeniorFarmer::orderBy('name')->get();
        $stores   = Supplier::orderBy('name')->get();

        return view('trangnong.form', compact('item', 'laonongs', 'stores'));
    }

public function update(Request $r, $id)
{
    $data = $r->validate([
        'name'       => 'required|string',
        'phone'      => 'required|string',
        'area'       => 'sometimes|nullable|string',
        'laonong_id' => 'required',
        'store_id'   => 'required',
        'status'     => 'required',
    ]);

    $item = TrangNong::findOrFail($id);
    $item->update($data);

    return redirect()->route('trangnong.index')
        ->with('success', 'Cập nhật tráng nông thành công !!');
}

 
     public function destroy($id)
    {
    $item = TrangNong::findOrFail($id);
    $item->delete();

return redirect()->route('trangnong.index')
    ->with('success', 'Xoá tráng nông thành công!');
  }
}