<?php
return [
    'default' => env('DB_CONNECTION', 'mongodb'),
    'connections' => [
        'mongodb' => [
            'driver' => 'mongodb',
            'dsn' => env('MONGODB_URI', 'mongodb://mongo_nongsanso:27017/agriiDB'),
            'host' => env('MONGODB_HOST', 'mongo_nongsanso'),
            'port' => env('MONGODB_PORT', 27017),
            'database' => env('MONGODB_DATABASE', 'agriiDB'),
            'username' => env('MONGODB_USERNAME', ''),
            'password' => env('MONGODB_PASSWORD', ''),
            'options' => ['appname' => 'agri-admin'],
        ],
    ],
    'migrations' => 'migrations',
];
