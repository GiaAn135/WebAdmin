<?php
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Admin\FarmerController;
use App\Http\Controllers\Admin\TrangNongController;
use App\Http\Controllers\Admin\LaoNongController;
use App\Http\Controllers\Admin\SupplierController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\CatalogController;
use App\Http\Controllers\Admin\OrderController;

Route::get('/', fn() => redirect()->route('farmers.index'));

Route::prefix('admin')->middleware(['web'])->group(function () {
  Route::resource('farmers', FarmerController::class)->names('farmers');
  Route::resource('trang-nong', TrangNongController::class)->names('trangnong');
  Route::resource('lao-nong', LaoNongController::class)->names('laonong');
  Route::resource('suppliers', SupplierController::class)->names('suppliers');
  Route::resource('products', ProductController::class)->names('products');
  Route::resource('catalog', CatalogController::class)->names('catalog');
  Route::resource('orders', OrderController::class)->names('orders');
  Route::post('orders/{order}/change-status', [\App\Http\Controllers\Admin\OrderController::class,'changeStatus'])
        ->name('orders.change-status');
  Route::get('orders', [OrderController::class, 'index'])->name('orders.index');

    Route::get('tracking', [OrderController::class, 'tracking'])->name('orders.tracking');
    
    // Các route cho các hành động xử lý trạng thái đơn (Duyệt, Xác nhận, Hủy...)
    Route::post('orders/{id}/approve-admin', [OrderController::class, 'approveByAdmin'])->name('orders.approveByAdmin');
    Route::post('orders/{id}/move-to-preparing', [OrderController::class, 'moveToPreparing'])->name('orders.moveToPreparing');
    Route::post('orders/{id}/move-to-ready-for-pickup', [OrderController::class, 'moveToReadyForPickup'])->name('orders.moveToReadyForPickup');
    Route::post('orders/{id}/move-to-awaiting-payment', [OrderController::class, 'moveToAwaitingPayment'])->name('orders.moveToAwaitingPayment');
    Route::post('orders/{id}/move-to-out-for-delivery', [OrderController::class, 'moveToOutForDelivery'])->name('orders.moveToOutForDelivery');
    Route::post('orders/{id}/move-to-delivered', [OrderController::class, 'moveToDelivered'])->name('orders.moveToDelivered');
    Route::post('orders/{id}/complete-order', [OrderController::class, 'completeOrder'])->name('orders.completeOrder');
    Route::post('orders/{id}/cancel-order', [OrderController::class, 'cancelOrder'])->name('orders.cancelOrder');

    // Route cho chi tiết đơn hàng
    Route::get('orders/{id}', [OrderController::class, 'show'])->name('orders.show');
    Route::get('orders/tracking', [OrderController::class, 'tracking'])->name('orders.tracking');
Route::get('/order-tracking', [OrderTrackingController::class, 'trackOrder'])->name('order.tracking');

    // Route xem chi tiết đơn hàng, sử dụng phương thức GET
    Route::get('orders/{id}', [OrderController::class, 'show'])->name('admin.orders.show');
    Route::get('orders/tracking', [OrderTrackingController::class, 'index'])->name('admin.orders.tracking');

    // Route xem chi tiết đơn hàng
    Route::get('orders/{id}', [OrderTrackingController::class, 'show'])->name('admin.orders.show');

});
