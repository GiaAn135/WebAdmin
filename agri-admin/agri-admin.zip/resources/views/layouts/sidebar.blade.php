{{-- resources/views/layouts/sidebar.blade.php --}}
<div class="sidebar">
    <ul class="menu">
        <!-- Existing Menu Items -->
        <li class="menu-item">
            <a href="{{ route('admin.dashboard') }}" class="{{ request()->routeIs('admin.dashboard') ? 'bg-green-500 text-white' : 'text-black' }}">
                Dashboard
            </a>
        </li>

        <!-- Add new "Theo dõi đơn hàng" menu item -->
        <li class="menu-item">
            <a href="{{ route('orders.tracking') }}" class="{{ request()->routeIs('orders.tracking') ? 'bg-green-500 text-white' : 'text-black' }}">
                Theo dõi đơn hàng
            </a>
        </li>

        <!-- Other menu items -->
    </ul>
</div>
