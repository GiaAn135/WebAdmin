<?php $__env->startSection('content'); ?>
<div class="fixed inset-0 bg-slate-900/80 flex items-center justify-center">
  <div class="bg-white rounded-2xl w-full max-w-xl shadow-2xl">
    <div class="flex items-center justify-between px-6 py-4 border-b">
      <div class="font-semibold">
        <?php echo e(isset($item->_id) ? 'Cập nhật Tráng nông' : 'Thêm Tráng nông'); ?>

      </div>
      <a href="<?php echo e(route('trangnong.index')); ?>" class="text-xl text-slate-400">×</a>
    </div>

    <form method="POST"
          action="<?php echo e(isset($item->_id) ? route('trangnong.update', $item->_id) : route('trangnong.store')); ?>"
          class="p-6 space-y-3">
      <?php echo csrf_field(); ?>
      <?php if(isset($item->_id)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

      <label class="text-xs">Tên Tráng nông *</label>
      <input name="name"
             value="<?php echo e(old('name', $item->name ?? '')); ?>"
             class="w-full px-3 py-2 border rounded"
             required>

      <label class="text-xs">Số điện thoại *</label>
      <input name="phone"
             value="<?php echo e(old('phone', $item->phone ?? '')); ?>"
             class="w-full px-3 py-2 border rounded"
             required>

      <label class="text-xs">Khu vực *</label>
      <input name="area"
             value="<?php echo e(old('area', $item->area ?? '')); ?>"
             class="w-full px-3 py-2 border rounded"
             required>

      
      <label class="text-xs">Lão nông giám sát *</label>
      <select name="laonong_id" class="w-full px-3 py-2 border rounded" required>
        <option value="">Chọn lão nông...</option>
        <?php $__currentLoopData = $laonongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($ln->_id); ?>"
            <?php echo e(old('laonong_id', $item->laonong_id ?? '') == $ln->_id ? 'selected' : ''); ?>>
            <?php echo e($ln->name); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      
      <label class="text-xs mt-3">Cửa hàng VTNN được gán *</label>
      <select name="store_id" class="w-full px-3 py-2 border rounded" required>
        <option value="">Chọn cửa hàng...</option>
        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($store->_id); ?>"
            <?php echo e(old('store_id', $item->store_id ?? '') == $store->_id ? 'selected' : ''); ?>>
            <?php echo e($store->name ?? $store->store_name); ?>

          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <label class="text-xs">Trạng thái *</label>
      <select name="status" class="w-full px-3 py-2 border rounded">
        <option value="active"   <?php echo e(old('status', $item->status ?? 'active') == 'active'   ? 'selected' : ''); ?>>Hoạt động</option>
        <option value="inactive" <?php echo e(old('status', $item->status) == 'inactive' ? 'selected' : ''); ?>>Ngưng</option>
      </select>

      <div class="flex justify-end gap-2 pt-3 border-t">
        <a href="<?php echo e(route('trangnong.index')); ?>" class="px-4 py-2 border rounded">
          <?php echo e(isset($item->_id) ? 'Đóng' : 'Huỷ'); ?>

        </a>
        <button class="px-4 py-2 bg-slate-900 text-white rounded">
          <?php echo e(isset($item->_id) ? 'Lưu thay đổi' : 'Lưu'); ?>

        </button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\trangnong\form.blade.php ENDPATH**/ ?>