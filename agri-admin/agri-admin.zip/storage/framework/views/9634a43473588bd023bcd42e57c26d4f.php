
<div class="sidebar">
    <ul class="menu">
        <!-- Existing Menu Items -->
        <li class="menu-item">
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="<?php echo e(request()->routeIs('admin.dashboard') ? 'bg-green-500 text-white' : 'text-black'); ?>">
                Dashboard
            </a>
        </li>

        <!-- Add new "Theo dõi đơn hàng" menu item -->
        <li class="menu-item">
            <a href="<?php echo e(route('orders.tracking')); ?>" class="<?php echo e(request()->routeIs('orders.tracking') ? 'bg-green-500 text-white' : 'text-black'); ?>">
                Theo dõi đơn hàng
            </a>
        </li>

        <!-- Other menu items -->
    </ul>
</div>
<?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\layouts\sidebar.blade.php ENDPATH**/ ?>