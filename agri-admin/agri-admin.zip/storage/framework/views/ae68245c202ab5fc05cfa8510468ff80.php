<?php $__env->startSection('content'); ?>
<div class="px-6 py-4">

    
    <div class="flex items-center justify-between mb-4">
        <div>
            <h1 class="text-lg font-semibold text-slate-800">Nông dân</h1>
            <p class="text-xs text-slate-500">
                Quản lý danh sách nông dân, lão nông, tráng nông và tổng đơn / tổng chi.
            </p>
        </div>

        <div class="flex items-center gap-2">
            <form method="GET" action="<?php echo e(route('farmers.index')); ?>">
                <div class="relative">
                    <input
                        type="text"
                        name="q"
                        value="<?php echo e(request('q')); ?>"
                        placeholder="Tìm kiếm mã, tên, SĐT..."
                        class="h-9 w-64 rounded border border-slate-200 px-3 text-sm focus:border-slate-400 focus:outline-none"
                    >
                </div>
            </form>

            <a href="<?php echo e(route('farmers.create')); ?>"
               class="inline-flex items-center rounded bg-emerald-600 px-4 py-2 text-sm font-medium text-white hover:bg-emerald-700">
                + Thêm nông dân
            </a>
        </div>
    </div>

    
    <div class="rounded-lg bg-white shadow border border-slate-100">
        
        <div class="flex items-center justify-between px-4 py-3 border-b border-slate-100">
            <div class="text-sm font-semibold text-slate-700">
                Danh sách Nông dân (<?php echo e($items->total()); ?>)
            </div>
        </div>

        <div class="overflow-x-auto">
            <table class="min-w-full text-xs md:text-sm">
                <thead class="bg-slate-50 border-b border-slate-100">
                    <tr class="text-left text-[11px] font-semibold text-slate-500 uppercase tracking-wide">
                        <th class="px-4 py-2 w-20">Mã</th>
                        <th class="px-2 py-2 w-40">Tên nông dân</th>
                        <th class="px-2 py-2 w-32">SĐT</th>
                        <th class="px-2 py-2 w-32">Khu vực</th>
                        <th class="px-2 py-2 w-28">LN phụ trách</th>
                        <th class="px-2 py-2 w-28">TN phụ trách</th>
                        <th class="px-2 py-2 text-right w-24">Tổng đơn</th>
                        <th class="px-2 py-2 text-right w-32">Tổng chi</th>
                        <th class="px-4 py-2 text-right w-24">Actions</th>
                    </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-b border-slate-100 hover:bg-slate-50">
                        
                        <td class="px-4 py-2 whitespace-nowrap text-slate-800">
                            <?php echo e($item->code); ?>

                        </td>

                        
                        <td class="px-2 py-2 whitespace-nowrap">
                            <?php echo e($item->name); ?>

                        </td>

                        
                        <td class="px-2 py-2 whitespace-nowrap">
                            <?php echo e($item->phone); ?>

                        </td>

                        
                        <td class="px-2 py-2 whitespace-nowrap">
                            <?php echo e($item->region); ?>

                        </td>

                        
                        <td class="px-2 py-2 whitespace-nowrap">
                            <?php echo e($item->lao_nong_code); ?>

                        </td>

                        
                        <td class="px-2 py-2 whitespace-nowrap">
                            <?php echo e($item->trang_nong_code); ?>

                        </td>

                        
                        <td class="px-2 py-2 text-right whitespace-nowrap">
                            <?php echo e(number_format($item->orders_count ?? 0)); ?>

                        </td>

                        
                        <td class="px-2 py-2 text-right whitespace-nowrap">
                            <?php echo e(number_format($item->total_cost ?? 0)); ?> đ
                        </td>

                        
                        <td class="px-4 py-2 whitespace-nowrap">
                            <div class="flex justify-end gap-2">
                                <a href="<?php echo e(route('farmers.edit', $item->_id)); ?>"
                                   class="inline-flex items-center rounded border border-slate-200 px-2 py-1 text-[11px] font-medium text-slate-700 hover:bg-slate-100">
                                    Sửa
                                </a>

                                <form method="POST"
                                      action="<?php echo e(route('farmers.destroy', $item->_id)); ?>"
                                      onsubmit="return confirm('Xóa nông dân này?');">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button
                                        type="submit"
                                        class="inline-flex items-center rounded border border-red-100 bg-red-50 px-2 py-1 text-[11px] font-medium text-red-600 hover:bg-red-100">
                                        Xóa
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="px-4 py-6 text-center text-slate-400">
                            Không có nông dân nào.
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>

        
        <div class="px-4 py-3 border-t border-slate-100">
            <?php echo e($items->withQueryString()->links()); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views/farmers/index.blade.php ENDPATH**/ ?>