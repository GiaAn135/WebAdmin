<?php $__env->startSection('content'); ?>
<?php
  $isEdit   = isset($item->_id);

  // variants
  $variants = old('variants', $item->variants ?? []);
  if (!is_array($variants)) $variants = [];
  $variantRows = max(count($variants), 3);

  // images
  $images = old('images', $item->images ?? []);
  if (!is_array($images)) {
      $images = $images ? [$images] : [];
  }
  $imageRows = max(count($images), 1);

  // Danh mục
  $catOptions = [
      'seeds'      => 'seeds',
      'tools'      => 'tools',
      'protection' => 'protection',
      'organic'    => 'organic',
  ];
  $selectedCat = old('category', $item->category ?? '');
?>

<div class="fixed inset-0 bg-slate-900/70 flex items-center justify-center px-4">
  
  <div class="bg-white rounded-2xl w-full max-w-4xl shadow-2xl text-xs">
    
    <div class="flex items-center justify-between px-3 py-2 border-b">
      <div class="font-semibold">
        <?php echo e($isEdit ? 'Cập nhật sản phẩm' : 'Thêm sản phẩm mới'); ?>

      </div>
      <a href="<?php echo e(route('products.index')); ?>" class="text-base text-slate-400 leading-none">×</a>
    </div>

    
    <form method="POST"
          action="<?php echo e($isEdit ? route('products.update', $item->_id) : route('products.store')); ?>"
          class="p-3 space-y-2">
      <?php echo csrf_field(); ?>
      <?php if($isEdit): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

      
      <div>
        <label class="font-semibold">Tên sản phẩm *</label>
        <input name="name"
               value="<?php echo e(old('name', $item->name ?? '')); ?>"
               class="w-full px-2 py-1.5 border rounded text-xs"
               required>
      </div>

      
      <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
        <div>
          <label class="font-semibold">Danh mục *</label>
          <select name="category"
                  class="w-full px-2 py-1.5 border rounded text-xs"
                  required>
            <?php $__currentLoopData = $catOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($value); ?>" <?php echo e($selectedCat === $value ? 'selected' : ''); ?>>
                <?php echo e($label); ?>

              </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div>
          <label class="font-semibold">Trạng thái</label>
          <?php $status = old('status', $item->status ?? 'active'); ?>
          <select name="status"
                  class="w-full px-2 py-1.5 border rounded text-xs">
            <option value="active" <?php echo e($status === 'active' ? 'selected' : ''); ?>>Đang bán</option>
            <option value="inactive" <?php echo e($status === 'inactive' ? 'selected' : ''); ?>>Ẩn</option>
          </select>
        </div>
      </div>

      
      <div class="grid grid-cols-1 md:grid-cols-2 gap-2">
        <div>
          <label class="font-semibold">Thương hiệu</label>
          <input name="brand"
                 value="<?php echo e(old('brand', $item->brand ?? '')); ?>"
                 class="w-full px-2 py-1.5 border rounded text-xs">
        </div>

        <div>
          <label class="font-semibold">Giá cơ bản (đ)</label>
          <input type="number" min="0" step="1000"
                 name="price"
                 value="<?php echo e(old('price', $item->price ?? '')); ?>"
                 class="w-full px-2 py-1.5 border rounded text-xs">
        </div>
      </div>

      
      <div>
        <label class="font-semibold">Video URL (YouTube / MP4)</label>
        <input type="url"
               name="videoUrl"
               value="<?php echo e(old('videoUrl', $item->videoUrl ?? '')); ?>"
               class="w-full px-2 py-1.5 border rounded text-xs">
      </div>

      
      <div>
        <label class="font-semibold">Ảnh sản phẩm (URL)</label>
        <p class="text-[10px] text-slate-400 mb-1">
          Mỗi dòng là một URL ảnh. Ảnh đầu tiên sẽ dùng làm thumbnail.
        </p>
        <?php for($i = 0; $i < $imageRows; $i++): ?>
          <input name="images[]"
                 value="<?php echo e($images[$i] ?? ''); ?>"
                 class="w-full px-2 py-1.5 border rounded text-xs mb-1">
        <?php endfor; ?>
      </div>

      
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-2">
        
        <div>
          <label class="font-semibold block mb-1">Biến thể (variants)</label>
          <p class="text-[10px] text-slate-400 mb-1">
            Ví dụ: "Gói 25kg", "1L"… Hệ thống sẽ lưu thành mảng
            <code>variants[{ name, price, quantity }]</code>.
          </p>

          <div class="overflow-x-auto border rounded">
            <table class="min-w-full text-[10px]">
              <thead class="bg-slate-50">
                <tr>
                  <th class="px-1.5 py-1 text-left w-1/2">Tên biến thể</th>
                  <th class="px-1.5 py-1 text-right w-1/4">Giá (đ)</th>
                  <th class="px-1.5 py-1 text-right w-1/4">Tồn kho</th>
                </tr>
              </thead>
              <tbody>
                <?php for($i = 0; $i < $variantRows; $i++): ?>
                  <?php
                    $v = $variants[$i] ?? ['name' => '', 'price' => '', 'quantity' => ''];
                  ?>
                  <tr class="border-t">
                    <td class="px-1.5 py-1">
                      <input name="variants[<?php echo e($i); ?>][name]"
                             value="<?php echo e($v['name'] ?? ''); ?>"
                             class="w-full px-1.5 py-1 border rounded text-[10px]">
                    </td>
                    <td class="px-1.5 py-1">
                      <input type="number" min="0" step="1000"
                             name="variants[<?php echo e($i); ?>][price]"
                             value="<?php echo e($v['price'] ?? ''); ?>"
                             class="w-full px-1.5 py-1 border rounded text-[10px] text-right">
                    </td>
                    <td class="px-1.5 py-1">
                      <input type="number" min="0" step="1"
                             name="variants[<?php echo e($i); ?>][quantity]"
                             value="<?php echo e($v['quantity'] ?? ''); ?>"
                             class="w-full px-1.5 py-1 border rounded text-[10px] text-right">
                    </td>
                  </tr>
                <?php endfor; ?>
              </tbody>
            </table>
          </div>
        </div>

        
        <div>
          <label class="font-semibold">Mô tả / Thông tin an toàn</label>
          <textarea name="description" rows="7"
                    class="w-full px-2 py-1.5 border rounded text-xs"><?php echo e(old('description', $item->description ?? '')); ?></textarea>
        </div>
      </div>

      
      <div class="flex justify-end gap-2 pt-2 border-t mt-1">
        <a href="<?php echo e(route('products.index')); ?>"
           class="px-3 py-1.5 border rounded text-xs">
          <?php echo e($isEdit ? 'Đóng' : 'Huỷ'); ?>

        </a>
        <button class="px-3 py-1.5 bg-slate-900 text-white rounded text-xs">
          <?php echo e($isEdit ? 'Lưu thay đổi' : 'Lưu'); ?>

        </button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\products\form.blade.php ENDPATH**/ ?>