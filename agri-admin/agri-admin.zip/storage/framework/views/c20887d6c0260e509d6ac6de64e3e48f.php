<?php $__env->startSection('content'); ?>
<div class="px-6 py-4 space-y-6">

    
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-semibold">
                Đơn hàng <?php echo e($order->code); ?>

            </h1>
            <p class="text-sm text-slate-500 mt-1">
                Nông dân: <span class="font-medium text-slate-700"><?php echo e($order->farmer_name); ?></span> ·
                Địa chỉ: <span class="font-medium text-slate-700"><?php echo e($order->region); ?></span>
            </p>
        </div>

        <a href="<?php echo e(route('orders.index')); ?>" class="text-sm text-slate-600 hover:underline">
            ← Quay lại danh sách
        </a>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border px-6 py-4">
        <?php
            $current = $order->current_step;
        ?>

        <ol class="flex items-center justify-between">
            <?php $__currentLoopData = $steps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li class="flex-1 flex flex-col items-center">
                    <div class="flex items-center w-full">
                        <div class="flex items-center justify-center w-8 h-8 rounded-full text-xs font-semibold
                            <?php echo e($value <= $current ? 'bg-emerald-500 text-white' : 'bg-slate-200 text-slate-600'); ?>">
                            <?php echo e($loop->iteration); ?>

                        </div>

                        <?php if(!$loop->last): ?>
                            <div class="h-0.5 flex-1 mx-1
                                <?php echo e($value < $current ? 'bg-emerald-500' : 'bg-slate-200'); ?>">
                            </div>
                        <?php endif; ?>
                    </div>
                    <p class="mt-2 text-[11px] text-center text-slate-700 leading-tight">
                        <?php echo e($step['label']); ?>

                    </p>
                </li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ol>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div class="bg-white rounded-xl shadow-sm border p-4 space-y-2">
            <h2 class="text-sm font-semibold text-slate-700 mb-2">Thông tin nông dân</h2>
            <p class="text-sm">Tên: <span class="font-medium"><?php echo e($order->farmer_name); ?></span></p>
            <p class="text-sm">Địa chỉ: <span class="font-medium"><?php echo e($order->region); ?></span></p>
        </div>

        <div class="bg-white rounded-xl shadow-sm border p-4 space-y-2">
            <h2 class="text-sm font-semibold text-slate-700 mb-2">LN / TN phụ trách</h2>
            <p class="text-sm">Lão nông: <span class="font-medium"><?php echo e($order->lao_nong_code); ?></span></p>
            <p class="text-sm">Tráng nông: <span class="font-medium"><?php echo e($order->trang_nong_code); ?></span></p>
        </div>

        <div class="bg-white rounded-xl shadow-sm border p-4 space-y-2">
            <h2 class="text-sm font-semibold text-slate-700 mb-2">Cửa hàng VTNN</h2>
            <p class="text-sm">Mã cửa hàng: <span class="font-medium"><?php echo e($order->store_code); ?></span></p>
            <p class="text-sm">
                Tổng tiền:
                <span class="font-semibold text-emerald-600">
                    <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?> đ
                </span>
            </p>
            <p class="text-sm">
                Trạng thái:
                <span class="inline-flex px-2 py-1 rounded-full text-xs font-medium <?php echo e($order->status_badge_class); ?>">
                    <?php echo e($order->status_label); ?>

                </span>
            </p>
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
        <table class="min-w-full text-sm">
            <thead class="bg-slate-50">
                <tr>
                    <th class="px-4 py-2 text-left font-semibold text-xs text-slate-500">Sản phẩm</th>
                    <th class="px-4 py-2 text-center font-semibold text-xs text-slate-500">SL</th>
                    <th class="px-4 py-2 text-right font-semibold text-xs text-slate-500">Giá</th>
                    <th class="px-4 py-2 text-right font-semibold text-xs text-slate-500">Thành tiền</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-t">
                        <td class="px-4 py-2 align-middle">
                            <div class="font-medium text-slate-800">
                                <?php echo e($item->product_code); ?> - <?php echo e($item->product_name); ?>

                            </div>
                            <?php if($item->variantName ?? false): ?>
                                <div class="mt-1 text-[11px] text-slate-500">
                                    <?php echo e($item->variantName); ?>

                                </div>
                            <?php endif; ?>
                        </td>
                        <td class="px-4 py-2 align-middle text-center">
                            <?php echo e($item->qty); ?>

                        </td>
                        <td class="px-4 py-2 align-middle text-right">
                            <?php echo e(number_format($item->price, 0, ',', '.')); ?> đ
                        </td>
                        <td class="px-4 py-2 align-middle text-right">
                            <?php echo e(number_format($item->subtotal, 0, ',', '.')); ?> đ
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="4" class="px-4 py-6 text-center text-slate-500">
                            Không có sản phẩm nào trong đơn.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
            <tfoot class="bg-slate-50">
                <tr>
                    <td colspan="3" class="px-4 py-2 text-right font-semibold">
                        Tổng cộng
                    </td>
                    <td class="px-4 py-2 text-right font-semibold text-emerald-600">
                        <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?> đ
                    </td>
                </tr>
            </tfoot>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\orders\show.blade.php ENDPATH**/ ?>