<?php $__env->startSection('content'); ?>
<div class="fixed inset-0 bg-slate-900/70 flex items-center justify-center">
    <div class="bg-white rounded-2xl w-full max-w-xl shadow-2xl">
        <div class="flex items-center justify-between px-6 py-4 border-b">
            <div class="font-semibold">
                <?php echo e(isset($item->_id) ? 'Cập nhật nông dân' : 'Thêm nông dân mới'); ?>

            </div>
            <a href="<?php echo e(route('farmers.index')); ?>" class="text-xl text-slate-400">×</a>
        </div>

        <form method="POST"
              action="<?php echo e(isset($item->_id) ? route('farmers.update', $item->_id) : route('farmers.store')); ?>"
              class="p-6 space-y-3">
            <?php echo csrf_field(); ?>
            <?php if(isset($item->_id)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

            <label class="text-xs">Tên nông dân *</label>
            <input name="name"
                   value="<?php echo e(old('name', $item->name)); ?>"
                   class="w-full px-3 py-2 border rounded"
                   required>

            <label class="text-xs">Số điện thoại *</label>
            <input name="phone"
                   value="<?php echo e(old('phone', $item->phone)); ?>"
                   class="w-full px-3 py-2 border rounded"
                   required>

            <label class="text-xs">Địa chỉ *</label>
            <input name="address"
                   value="<?php echo e(old('address', $item->address)); ?>"
                   class="w-full px-3 py-2 border rounded"
                   required>

            <label class="text-xs">Khu vực *</label>
            <input name="region"
                   value="<?php echo e(old('region', $item->region)); ?>"
                   class="w-full px-3 py-2 border rounded"
                   required>

            
            <label class="text-xs">LN phụ trách *</label>
            <select name="lao_nong_code"
                    class="w-full px-3 py-2 border rounded"
                    required>
                <option value="">Chọn lão nông phụ trách</option>
                <?php $__currentLoopData = $seniorFarmers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ln): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($ln->code); ?>"
                        <?php echo e(old('lao_nong_code', $item->lao_nong_code ?? '') == $ln->code ? 'selected' : ''); ?>>
                        <?php echo e($ln->code); ?> - <?php echo e($ln->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            
            <label class="text-xs">TN phụ trách *</label>
            <select name="trang_nong_code"
                    class="w-full px-3 py-2 border rounded"
                    required>
                <option value="">Chọn tráng nông phụ trách</option>
                <?php $__currentLoopData = $trangNongs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($tn->code); ?>"
                        <?php echo e(old('trang_nong_code', $item->trang_nong_code ?? '') == $tn->code ? 'selected' : ''); ?>>
                        <?php echo e($tn->code); ?> - <?php echo e($tn->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <div class="flex justify-end gap-2 pt-3 border-t mt-2">
                <a href="<?php echo e(route('farmers.index')); ?>"
                   class="px-4 py-2 border rounded">
                    <?php echo e(isset($item->_id) ? 'Đóng' : 'Huỷ'); ?>

                </a>
                <button class="px-4 py-2 bg-slate-900 text-white rounded">
                    <?php echo e(isset($item->_id) ? 'Lưu thay đổi' : 'Lưu'); ?>

                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\farmers\form.blade.php ENDPATH**/ ?>