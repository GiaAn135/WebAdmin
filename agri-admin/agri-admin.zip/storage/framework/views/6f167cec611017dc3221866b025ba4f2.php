<?php $__env->startSection('content'); ?>
<div class="px-6 py-6">

    
    <div class="flex items-center justify-between mb-4">
        <div>
            <h1 class="text-lg font-semibold">Danh mục Sản phẩm tại VTNN</h1>
            <p class="mt-1 text-xs text-slate-500">
                Giá bán, chiết khấu TN/LN và tồn kho cho từng sản phẩm tại từng cửa hàng VTNN.
            </p>
        </div>

        <a href="<?php echo e(route('catalog.create')); ?>"
           class="inline-flex items-center px-4 py-2 text-sm font-medium text-white bg-emerald-600 rounded-lg hover:bg-emerald-700">
            + Thêm mới
        </a>
    </div>

    
    <?php if(session('success')): ?>
        <div class="mb-4 text-sm text-emerald-700 bg-emerald-50 border border-emerald-200 px-4 py-2 rounded-lg">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    
    <div class="flex items-center justify-between mb-4">
        <form method="GET" action="<?php echo e(route('catalog.index')); ?>" class="flex-1 max-w-md">
            <div class="relative">
                <input
                    type="text"
                    name="q"
                    value="<?php echo e(request('q')); ?>"
                    placeholder="Tìm kiếm VTNN, sản phẩm..."
                    class="w-full px-3 py-2 text-sm border rounded-lg focus:outline-none focus:ring-1 focus:ring-slate-500"
                >
            </div>
        </form>
    </div>

    
    <div class="overflow-hidden bg-white border rounded-xl">
        <table class="min-w-full text-sm">
            <thead class="bg-slate-50 text-xs text-slate-500">
                <tr>
                    <th class="px-4 py-2 text-left align-middle">VTNN</th>
                    <th class="px-4 py-2 text-left align-middle">Sản phẩm</th>
                    <th class="px-4 py-2 text-right align-middle">Giá bán</th>
                    <th class="px-4 py-2 text-center align-middle">Chiết khấu TN</th>
                    <th class="px-4 py-2 text-center align-middle">Chiết khấu LN</th>
                    <th class="px-4 py-2 text-center align-middle">Tồn kho</th>
                    <th class="px-4 py-2 text-center align-middle w-24">Trạng thái</th>
                    <th class="px-4 py-2 text-center align-middle w-28">Hành động</th>
                </tr>
            </thead>

            <tbody class="divide-y">
            <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="hover:bg-slate-50">
                    
                    <td class="px-4 py-2 align-middle whitespace-nowrap">
                        <?php if($item->store): ?>
                            <?php echo e($item->store->name); ?>

                            <?php if(!empty($item->store->code)): ?>
                                (<?php echo e($item->store->code); ?>)
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>

                    
                    <td class="px-4 py-2 align-middle whitespace-nowrap">
                        <?php if($item->product): ?>
                            <?php echo e($item->product->name); ?>

                            <?php if(!empty($item->product->sku)): ?>
                                (<?php echo e($item->product->sku); ?>)
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>

                    
                    <td class="px-4 py-2 text-right align-middle whitespace-nowrap">
                        <?php echo e(number_format($item->price ?? 0, 0, ',', '.')); ?>đ
                    </td>

                    
                    <td class="px-4 py-2 text-center align-middle whitespace-nowrap">
                        <?php echo e($item->discount_tn ?? 0); ?>%
                    </td>

                    
                    <td class="px-4 py-2 text-center align-middle whitespace-nowrap">
                        <?php echo e($item->discount_ln ?? 0); ?>%
                    </td>

                    
                    <td class="px-4 py-2 text-center align-middle whitespace-nowrap">
                        <?php echo e($item->stock ?? 0); ?>

                    </td>

                    
                    <td class="px-4 py-2 text-center align-middle">
                        <?php if(($item->status ?? 'active') === 'active'): ?>
                            <span class="px-2 py-0.5 text-xs font-medium text-emerald-700 bg-emerald-50 rounded-full">
                                Hoạt động
                            </span>
                        <?php else: ?>
                            <span class="px-2 py-0.5 text-xs font-medium text-rose-700 bg-rose-50 rounded-full">
                                Ngưng
                            </span>
                        <?php endif; ?>
                    </td>

                    
                    <td class="px-4 py-2 text-center align-middle">
                        <div class="flex items-center justify-center gap-2">
                            
                            <a href="<?php echo e(route('catalog.edit', $item->_id)); ?>"
                               class="inline-flex items-center justify-center w-7 h-7 text-xs bg-slate-100 hover:bg-slate-200 rounded-md"
                               title="Sửa">
                                ✏️
                            </a>

                            
                            <form action="<?php echo e(route('catalog.destroy', $item->_id)); ?>"
                                  method="POST"
                                  onsubmit="return confirm('Xoá mục Catalog này?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit"
                                        class="inline-flex items-center justify-center w-7 h-7 text-xs text-white bg-rose-500 hover:bg-rose-600 rounded-md"
                                        title="Xoá">
                                    🗑
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="8" class="px-4 py-6 text-sm text-center text-slate-500">
                        Chưa có dữ liệu Catalog VTNN.
                    </td>
                </tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>

    
    <div class="mt-4">
        <?php echo e($items->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\catalog\index.blade.php ENDPATH**/ ?>