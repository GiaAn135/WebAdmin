<?php $__env->startSection('content'); ?>
<div class="flex items-center justify-between mb-4">
  <h1 class="text-xl font-semibold">Danh mục Cửa hàng VTNN</h1>
  <a href="<?php echo e(route('suppliers.create')); ?>" class="px-3 py-2 bg-emerald-600 text-white rounded text-sm">+ Thêm mới</a>
</div>
<div class="bg-white rounded-xl border">
  <div class="overflow-x-auto">
    <table class="min-w-full text-xs">
      <thead class="bg-slate-50 text-slate-600">
        <tr><th class='px-3 py-2'>Mã</th><th class='px-3 py-2'>Tên cửa hàng</th><th class='px-3 py-2'>SĐT</th><th class='px-3 py-2'>Địa chỉ</th><th class='px-3 py-2'>Trạng thái</th><th class='px-3 py-2'>Actions</th></tr>
      </thead>
      <tbody class="divide-y">
        <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
<td class='px-3 py-2'><?php echo e($item->code ?? ''); ?></td>
<td class='px-3 py-2'><?php echo e($item->name ?? ''); ?></td>
<td class='px-3 py-2'><?php echo e($item->phone ?? ''); ?></td>
<td class='px-3 py-2'><?php echo e($item->address ?? ''); ?></td>
<td class='px-3 py-2'><?php echo e($item->status ?? ''); ?></td>
          <td class="px-3 py-2">
            <div class="flex gap-2 justify-center">
              <a href="<?php echo e(route('suppliers.edit',$item->_id)); ?>" class="px-2 py-1 bg-slate-100 rounded">✏️</a>
              <form method="POST" action="<?php echo e(route('suppliers.destroy',$item->_id)); ?>" onsubmit="return confirm('Xác nhận xoá?')">
                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                <button class="px-2 py-1 bg-slate-100 rounded text-rose-600">🗑</button>
              </form>
            </div>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6" class="px-3 py-4 text-center text-slate-400">Chưa có dữ liệu</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <div class="p-3 text-right"><?php echo e($items->withQueryString()->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\suppliers\index.blade.php ENDPATH**/ ?>