<?php $__env->startSection('content'); ?>
<div class="fixed inset-0 bg-slate-900/80 flex items-center justify-center">
  <div class="bg-white rounded-2xl w-full max-w-xl shadow-2xl">
    <div class="flex items-center justify-between px-6 py-4 border-b">
      <div class="font-semibold"><?php echo e(isset($item->_id) ? 'Cập nhật sản phẩm' : 'Thêm sản phẩm mới'); ?></div>
      <a href="<?php echo e(route('products.index')); ?>" class="text-xl text-slate-400">×</a>
    </div>
    <form method="POST" action="<?php echo e(isset($item->_id) ? route('products.update',$item->_id) : route('products.store')); ?>" class="p-6 space-y-3">
      <?php echo csrf_field(); ?> <?php if(isset($item->_id)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

      

      <label class='text-xs'>Tên sản phẩm *</label>
      <input name='name' value='<?php echo e(old("name",$item->name)); ?>' class='w-full px-3 py-2 border rounded' required>

      <label class='text-xs'>Danh mục *</label>
      <select name="category" class="w-full px-3 py-2 border rounded" required>
        <?php $__currentLoopData = ['phan_bon'=>'Phân bón','thuoc_bvtv'=>'Thuốc BVTV','giong_cay_trong'=>'Giống cây trồng']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($key); ?>" <?php echo e(old('category',$item->category) === $key ? 'selected' : ''); ?>><?php echo e($label); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <label class='text-xs'>Cửa hàng VTNN (lấy CK) *</label>
      <select name="vtnn_name" class="w-full px-3 py-2 border rounded" required>
        <option value="">— Chọn cửa hàng —</option>
        <?php $__currentLoopData = ($suppliers ?? []); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($name); ?>" <?php echo e(old('vtnn_name',$item->vtnn_name) === $name ? 'selected' : ''); ?>><?php echo e($name); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      <div class='grid grid-cols-2 gap-3'>
        <div>
          <label class='text-xs'>Đơn vị tính *</label>
          <input name='unit' value='<?php echo e(old("unit",$item->unit)); ?>' class='w-full px-3 py-2 border rounded' required>
        </div>
        <div>
          <label class='text-xs'>Giá niêm (VND) *</label>
          <input type='number' name='list_price' value='<?php echo e(old("list_price",$item->list_price)); ?>' class='w-full px-3 py-2 border rounded' required>
        </div>
      </div>

      <div class='grid grid-cols-2 gap-3'>
        <div><label class='text-xs'>Tồn kho</label>
          <input type='number' name='stock' value='<?php echo e(old("stock",$item->stock)); ?>' class='w-full px-3 py-2 border rounded'></div>
        <div>
          <label class='text-xs'>Trạng thái *</label>
          <select name='status' class='w-full px-3 py-2 border rounded'>
            <option value='active' <?php echo e(old('status',$item->status ?? 'active')=='active'?'selected':''); ?>>Hoạt động</option>
            <option value='inactive' <?php echo e(old('status',$item->status)=='inactive'?'selected':''); ?>>Ngưng</option>
          </select>
        </div>
      </div>

      <label class='text-xs'>Mô tả / Specs</label>
      <textarea name='description' rows='3' class='w-full px-3 py-2 border rounded'><?php echo e(old("description",$item->description)); ?></textarea>

      <div class="flex justify-end gap-2 pt-3 border-t">
        <a href="<?php echo e(route('products.index')); ?>" class="px-4 py-2 border rounded"><?php echo e(isset($item->_id) ? 'Đóng' : 'Huỷ'); ?></a>
        <button class="px-4 py-2 bg-slate-900 text-white rounded"><?php echo e(isset($item->_id) ? 'Lưu thay đổi' : 'Lưu'); ?></button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\admin\products\form.blade.php ENDPATH**/ ?>