<?php $__env->startSection('content'); ?>
<div class="fixed inset-0 bg-slate-900/80 flex items-center justify-center">
  <div class="bg-white rounded-2xl w-full max-w-xl shadow-2xl">
    <div class="flex items-center justify-between px-6 py-4 border-b">
      <div class="font-semibold">
        <?php echo e(isset($item->_id) ? 'Cập nhật Catalog VTNN' : 'Thêm Catalog VTNN'); ?>

      </div>
      <a href="<?php echo e(route('catalog.index')); ?>" class="text-xl text-slate-400">×</a>
    </div>

    <form method="POST"
          action="<?php echo e(isset($item->_id) ? route('catalog.update',$item->_id) : route('catalog.store')); ?>"
          class="p-6 space-y-3">
      <?php echo csrf_field(); ?>
      <?php if(isset($item->_id)): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>

      
      <label class="text-xs">Cửa hàng VTNN *</label>
      <select name="store_id"
              class="w-full px-3 py-2 border rounded"
              required>
        <option value="">Vui lòng chọn cửa hàng</option>
        <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($store->_id); ?>"
            <?php echo e(old('store_id', $item->store_id ?? '') == $store->_id ? 'selected' : ''); ?>>
            <?php echo e($store->name); ?> <?php if(!empty($store->code)): ?> (<?php echo e($store->code); ?>) <?php endif; ?>
          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      
      <label class="text-xs">Sản phẩm *</label>
      <select name="product_id"
              class="w-full px-3 py-2 border rounded"
              required>
        <option value="">Vui lòng chọn sản phẩm</option>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($product->_id); ?>"
            <?php echo e(old('product_id', $item->product_id ?? '') == $product->_id ? 'selected' : ''); ?>>
            <?php echo e($product->name); ?> <?php if(!empty($product->sku)): ?> (<?php echo e($product->sku); ?>) <?php endif; ?>
          </option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </select>

      
      <label class="text-xs">Giá bán (VND) *</label>
      <input type="number" name="price"
             value="<?php echo e(old('price', $item->price ?? '')); ?>"
             class="w-full px-3 py-2 border rounded" required>

      <div class="grid grid-cols-2 gap-3">
        <div>
          <label class="text-xs">Chiết khấu TN *</label>
          <input type="number" step="0.01" name="discount_tn"
                 value="<?php echo e(old('discount_tn', $item->discount_tn ?? '')); ?>"
                 class="w-full px-3 py-2 border rounded" required>
        </div>
        <div>
          <label class="text-xs">Chiết khấu LN *</label>
          <input type="number" step="0.01" name="discount_ln"
                 value="<?php echo e(old('discount_ln', $item->discount_ln ?? '')); ?>"
                 class="w-full px-3 py-2 border rounded" required>
        </div>
      </div>

      
      <label class="text-xs">Số lượng tồn kho *</label>
      <input type="number" name="stock"
             value="<?php echo e(old('stock', $item->stock ?? '')); ?>"
             class="w-full px-3 py-2 border rounded" required>

      
      <label class="text-xs">Trạng thái *</label>
      <select name="status" class="w-full px-3 py-2 border rounded">
        <option value="active"
          <?php echo e(old('status', $item->status ?? 'active') == 'active' ? 'selected' : ''); ?>>
          Hoạt động
        </option>
        <option value="inactive"
          <?php echo e(old('status', $item->status ?? '') == 'inactive' ? 'selected' : ''); ?>>
          Ngưng
        </option>
      </select>

      <div class="flex justify-end gap-2 pt-3 border-t">
        <a href="<?php echo e(route('catalog.index')); ?>"
           class="px-4 py-2 border rounded">
           <?php echo e(isset($item->_id) ? 'Đóng' : 'Huỷ'); ?>

        </a>
        <button class="px-4 py-2 bg-slate-900 text-white rounded">
          <?php echo e(isset($item->_id) ? 'Lưu thay đổi' : 'Lưu'); ?>

        </button>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views\catalog\form.blade.php ENDPATH**/ ?>