



<?php $__env->startSection('title', 'Theo dõi giao hàng'); ?>

<?php $__env->startSection('content'); ?>
<div class="px-6 py-4 space-y-4">

    
    <div class="flex items-center justify-between">
        <div>
            <h1 class="text-xl font-semibold text-slate-800">Theo dõi giao hàng</h1>
            <p class="text-sm text-slate-500 mt-1">
                Bản đồ và danh sách đơn theo trạng thái
            </p>
        </div>

        <form method="GET" class="flex items-center gap-2">
            <select name="status"
                    class="px-3 py-2 border rounded-lg text-sm text-slate-700 bg-white">
                <option value="">Tất cả trạng thái</option>
                <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $config): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($key); ?>" <?php echo e(request('status') === $key ? 'selected' : ''); ?>>
                        <?php echo e($config['value']); ?>. <?php echo e($config['label']); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button type="submit"
                    class="px-4 py-2 rounded-lg bg-emerald-600 text-white text-sm font-medium hover:bg-emerald-700">
                Lọc
            </button>
        </form>
    </div>

    
    <div class="bg-white rounded-xl border shadow-sm overflow-hidden">
        <div class="px-6 py-3 border-b">
            <h2 class="text-sm font-semibold text-slate-700">Bản đồ giao hàng</h2>
        </div>
        
        <div id="delivery-map" style="width: 100%; height: 500px;" class="bg-gray-100">
            <div class="h-full flex items-center justify-center text-slate-500 text-sm">
                Đang tải bản đồ...
            </div>
        </div>
    </div>

    
    <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
        <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <div class="bg-white rounded-xl border shadow-sm p-4 flex flex-col justify-between">

                
                <div>
                    <div class="flex items-center justify-between mb-2">
                        <span class="text-sm font-semibold text-slate-800">
                            <?php echo e($order->code); ?>

                        </span>
                        <span class="text-xs font-semibold text-emerald-600">
                            <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?> đ
                        </span>
                    </div>

                    
                    <span class="inline-flex px-3 py-1 rounded-full text-xs font-medium <?php echo e($order->status_badge_class); ?>">
                        <?php echo e($order->status_label); ?>

                    </span>
                    
                    <?php if(isset($order->shipping_address)): ?>
                    <p class="text-xs text-slate-500 mt-2 line-clamp-2">
                        <i class="fas fa-map-marker-alt mr-1"></i> <?php echo e($order->shipping_address); ?>

                    </p>
                    <?php endif; ?>
                </div>

                
                <div class="mt-4 flex gap-2">
                    
                    <?php if($order->status === 'pending_admin_approval'): ?>
                        <form method="POST" action="<?php echo e(route('orders.approveByAdmin', $order->_id ?? $order->id)); ?>" class="flex-1">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full h-9 text-xs font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-700">
                                Duyệt
                            </button>
                        </form>
                    <?php elseif($order->status === 'pending_vtnn_prep'): ?>
                        <form method="POST" action="<?php echo e(route('orders.moveToPreparing', $order->_id ?? $order->id)); ?>" class="flex-1">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full h-9 text-xs font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-700">
                                Chuyển sang chuẩn bị
                            </button>
                        </form>
                    <?php elseif($order->status === 'preparing'): ?>
                        <form method="POST" action="<?php echo e(route('orders.moveToReadyForPickup', $order->_id ?? $order->id)); ?>" class="flex-1">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full h-9 text-xs font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-700">
                                Sẵn sàng lấy hàng
                            </button>
                        </form>
                    <?php elseif($order->status === 'ready_for_pickup'): ?>
                        <form method="POST" action="<?php echo e(route('orders.moveToAwaitingPayment', $order->_id ?? $order->id)); ?>" class="flex-1">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full h-9 text-xs font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-700">
                                Chờ thanh toán
                            </button>
                        </form>
                    <?php elseif($order->status === 'awaiting_payment'): ?>
                        <form method="POST" action="<?php echo e(route('orders.moveToOutForDelivery', $order->_id ?? $order->id)); ?>" class="flex-1">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full h-9 text-xs font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-700">
                                Đi giao hàng
                            </button>
                        </form>
                    <?php elseif($order->status === 'out_for_delivery'): ?>
                        
                        <form method="GET" action="<?php echo e(route('orders.show', $order->_id ?? $order->id)); ?>" class="flex-1">
                            <button type="submit"
                                class="w-full h-9 text-xs font-medium rounded-lg bg-white text-slate-800 border border-slate-300 hover:bg-slate-100">
                                Xem chi tiết
                            </button>
                        </form>
                    <?php elseif($order->status === 'delivered'): ?>
                        <form method="POST" action="<?php echo e(route('orders.completeOrder', $order->_id ?? $order->id)); ?>" class="flex-1">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full h-9 text-xs font-medium rounded-lg bg-emerald-600 text-white hover:bg-emerald-700">
                                Hoàn thành
                            </button>
                        </form>
                    <?php elseif($order->status === 'completed'): ?>
                        <form method="POST" action="<?php echo e(route('orders.cancelOrder', $order->_id ?? $order->id)); ?>" class="flex-1">
                            <?php echo csrf_field(); ?>
                            <button type="submit"
                                class="w-full h-9 text-xs font-medium rounded-lg bg-rose-600 text-white hover:bg-rose-700">
                                Hủy đơn
                            </button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <p class="text-sm text-slate-500 col-span-full">
                Không có đơn hàng nào phù hợp với bộ lọc.
            </p>
        <?php endif; ?>
    </div>
</div>


<script>
    function initMap() {
        // Lấy dữ liệu đơn hàng từ PHP
        const orders = <?php echo json_encode($orders, 15, 512) ?>;
        
        // Tọa độ mặc định (ví dụ: Hà Nội)
        const defaultCenter = { lat: 21.0285, lng: 105.8542 };
        
        const map = new google.maps.Map(document.getElementById("delivery-map"), {
            zoom: 12,
            center: defaultCenter,
        });

        const infoWindow = new google.maps.InfoWindow();
        const bounds = new google.maps.LatLngBounds();
        let hasMarkers = false;

        orders.forEach((order) => {
            // Lấy tọa độ. Bạn cần đảm bảo data $order->latitude và $order->longitude tồn tại
            // Nếu bạn lưu trong các trường khác (ví dụ: lat, lng), hãy sửa lại dòng này.
            let lat = parseFloat(order.latitude || order.lat); 
            let lng = parseFloat(order.longitude || order.lng);

            // Xử lý trường hợp tọa độ nằm trong object address (ví dụ: order.address.lat)
            if (isNaN(lat) && order.shipping_address_data) {
                lat = parseFloat(order.shipping_address_data.lat || order.shipping_address_data.latitude);
                lng = parseFloat(order.shipping_address_data.lng || order.shipping_address_data.longitude);
            }
            
            if (!isNaN(lat) && !isNaN(lng)) {
                const position = { lat: lat, lng: lng };
                
                const marker = new google.maps.Marker({
                    position: position,
                    map: map,
                    title: order.code,
                    // Tùy chỉnh icon dựa trên trạng thái (ví dụ)
                    icon: order.status === 'out_for_delivery' ? 
                          { url: 'https://maps.google.com/mapfiles/ms/icons/red-dot.png' } :
                          { url: 'https://maps.google.com/mapfiles/ms/icons/blue-dot.png' }
                });

                const content = `
                    <div style="padding:5px; color: black;">
                        <h4 style="margin:0;">Mã Đơn: <b>${order.code}</b></h4>
                        <p style="margin:2px 0; font-size:13px;">Trạng thái: ${order.status_label}</p>
                        <p style="margin:2px 0; font-size:13px;">Tổng tiền: ${new Intl.NumberFormat('vi-VN').format(order.total_amount)} đ</p>
                        <a href="${'/orders/' + (order._id || order.id)}" target="_blank" style="color:#059669; font-size:12px;">Xem chi tiết</a>
                    </div>
                `;

                marker.addListener("click", () => {
                    infoWindow.setContent(content);
                    infoWindow.open(map, marker);
                });

                bounds.extend(position);
                hasMarkers = true;
            }
        });

        // Tự động căn chỉnh bản đồ để bao gồm tất cả marker
        if (hasMarkers) {
            map.fitBounds(bounds);
        }
    }
</script>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCKKh0zOa2fwOfbsMWA1I2J1oviNAuM5h0&callback=initMap" async defer></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views/orders/tracking.blade.php ENDPATH**/ ?>