<?php $__env->startSection('content'); ?>
<div class="px-6 py-4">
    <h1 class="text-xl font-semibold mb-4">Điều phối đơn</h1>

    
    <div class="flex items-center justify-between mb-4 gap-3">
        <form method="GET" class="flex items-center gap-2 flex-1">
            <input
                type="text"
                name="q"
                value="<?php echo e(request('q')); ?>"
                placeholder="Tìm mã đơn, nông dân, địa chỉ…"
                class="w-full px-3 py-2 border rounded-lg text-sm"
            >

            <select name="status" class="px-3 py-2 border rounded-lg text-sm">
                <option value="">Tất cả trạng thái</option>
                <?php $__currentLoopData = $statusOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $step): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($value); ?>" <?php echo e(request('status') == $value ? 'selected' : ''); ?>>
                        <?php echo e($step['label']); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>

            <button
                type="submit"
                class="px-4 py-2 bg-emerald-600 text-white text-sm rounded-lg hover:bg-emerald-700"
            >
                Lọc
            </button>
        </form>

        <div class="text-xs text-slate-500">
            Tổng: <?php echo e($orders->total()); ?> đơn
        </div>
    </div>

    
    <div class="bg-white rounded-xl shadow-sm border overflow-x-auto">
        <table class="min-w-full text-sm">
            <thead class="bg-slate-50">
                <tr>
                    <th class="px-4 py-2 text-left font-semibold text-xs text-slate-500">Mã đơn</th>
                    <th class="px-4 py-2 text-left font-semibold text-xs text-slate-500">Nông dân</th>
                    <th class="px-4 py-2 text-left font-semibold text-xs text-slate-500">Địa chỉ</th>
                    <th class="px-4 py-2 text-right font-semibold text-xs text-slate-500">Tổng tiền</th>
                    <th class="px-4 py-2 text-center font-semibold text-xs text-slate-500">Trạng thái</th>
                    <th class="px-4 py-2 text-left font-semibold text-xs text-slate-500">Ngày tạo</th>
                    <th class="px-4 py-2 text-left font-semibold text-xs text-slate-500">TN/LN</th>
                    <th class="px-4 py-2 text-left font-semibold text-xs text-slate-500">VTNN</th>
                    <th class="px-4 py-2 text-right font-semibold text-xs text-slate-500">Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr class="border-t hover:bg-slate-50">
                        <td class="px-4 py-2 align-middle font-medium text-slate-800">
                            <?php echo e($order->code); ?>

                        </td>
                        <td class="px-4 py-2 align-middle">
                            <?php echo e($order->farmer_name); ?>

                        </td>
                        <td class="px-4 py-2 align-middle text-slate-600">
                            <?php echo e($order->region); ?>

                        </td>
                        <td class="px-4 py-2 align-middle text-right">
                            <?php echo e(number_format($order->total_amount, 0, ',', '.')); ?> đ
                        </td>
                        <td class="px-4 py-2 align-middle text-center">
                            <span class="inline-flex px-2 py-1 rounded-full text-xs font-medium <?php echo e($order->status_badge_class); ?>">
                                <?php echo e($order->status_label); ?>

                            </span>
                        </td>
                        <td class="px-4 py-2 align-middle text-slate-600">
                            <?php echo e(optional($order->createdAt)->format('d/m/Y')); ?>

                        </td>
                        <td class="px-4 py-2 align-middle text-slate-600">
                            <?php echo e($order->trang_nong_code); ?> / <?php echo e($order->lao_nong_code); ?>

                        </td>
                        <td class="px-4 py-2 align-middle text-slate-600">
                            <?php echo e($order->store_code); ?>

                        </td>
                        <td class="px-4 py-2 align-middle text-right">
                            <a href="<?php echo e(route('orders.show', $order->_id ?? $order->id)); ?>"
                               class="text-sm text-emerald-600 hover:underline">
                                Chi tiết
                            </a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="px-4 py-6 text-center text-slate-500">
                            Chưa có đơn hàng nào.
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4">
        <?php echo e($orders->withQueryString()->links()); ?>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\XAMPP\htdocs\agri-admin\resources\views/orders/index.blade.php ENDPATH**/ ?>